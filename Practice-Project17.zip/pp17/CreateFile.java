package pp17;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class CreateFile {

    public static void main(String[] args) {

        File myFile = new File("C:\\Users\\Surya Pratap Ajey\\eclipse-workspace\\SL_ASSISTED_PROJECT\\src\\myfile.txt");
        try {
            myFile.createNewFile();
            System.out.println("File created successfully.");
        } catch (IOException e) {
        	System.out.println("Unable to create this file");
            e.printStackTrace();
        }
    }
}
