package pp17;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
public class WriteFile {

    public static void main(String[] args) {

        File myFile = new File("C:\\Users\\Surya Pratap Ajey\\eclipse-workspace\\SL_ASSISTED_PROJECT\\src\\myfile.txt");
        try {
            FileWriter fileWriter = new FileWriter(myFile);
            fileWriter.write("This is first line\nI am writing in file.");
            fileWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}