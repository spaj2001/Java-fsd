package pp17;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class DeleteFile {

    public static void main(String[] args) {

        File myFile = new File("C:\\Users\\Surya Pratap Ajey\\eclipse-workspace\\SL_ASSISTED_PROJECT\\src\\myfile.txt");
        if(myFile.delete()){
            System.out.println("I have deleted: " + myFile.getName());
        }
        else{
            System.out.println("Some problem occurred while deleting the file");
        }

    }

}