package pp18;

class Employee{
    int id;
    int salary;
    String name;
    public void printDetails(){
        System.out.println("My id is " + id);
        System.out.println("and my name is "+ name);
    }

    public int getSalary(){
        return salary;
    }
}

public class ClassAndObjects {
    public static void main(String[] args) {
        System.out.println("This is our custom class");
        Employee ramesh = new Employee(); // Instantiating a new Employee Object
        Employee john = new Employee(); // Instantiating a new Employee Object

        // Setting Attributes for Ramesh
        ramesh.id = 12;
        ramesh.salary = 34;
        ramesh.name = "CodeWithHarry";

        // Setting Attributes for John
        john.id = 17;
        john.salary = 12;
        john.name = "John Khandelwal";

        // Printing the Attributes
        ramesh.printDetails();
        john.printDetails();
        int salary = john.getSalary();
        System.out.println(salary);
        System.out.println(ramesh.id);
        System.out.println(ramesh.name);
    }
}
