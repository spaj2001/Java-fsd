package pp18;

	abstract class Parent{
	   
	    public int sayHello(){
	        System.out.println("Hello");
	        return 0;
	    }
	    abstract public void greet();
	    abstract public void greet2();
	}

	class Child extends Parent{
	    @Override
	    public void greet(){
	        System.out.println("Good morning");
	        
	    }
	    @Override
	    public void greet2(){
	        System.out.println("Good afternoon");
	        
	    }
	}

	
public class AbstractionExample {
	    public static void main(String[] args) {
	        
	        Child c = new Child();	
	        c.greet();
	        c.greet2();
	        c.sayHello();
	    }
}
