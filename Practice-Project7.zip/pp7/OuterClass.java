package pp7;

public class OuterClass {



		 private String s="Hello"; 
		 
		 class InnerClass{  
		  void hello(){System.out.println(s+", to the World!!!");}  
		 }  


		public static void main(String[] args) {

			OuterClass o=new OuterClass();
			OuterClass.InnerClass i=o.new InnerClass();  
			i.hello();  
		}
	}

