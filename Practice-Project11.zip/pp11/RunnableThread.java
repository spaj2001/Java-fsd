package pp11;

class t1 implements Runnable {
	       @Override
	       public void run(){
	    	   int i =0;
		        while(i<40000){
		            System.out.println("My Thread is Running by implementing runnable");
		            System.out.println("I am sad!");
		            i++;
	       }
	}
}
public class RunnableThread{
	    public static void main(String[] args) {
	          t1 obj1 = new t1(); 
	         Thread t = new Thread(obj1); 
	         t.start();
	    }
}
