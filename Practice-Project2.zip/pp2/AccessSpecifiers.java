package pp2;

	class C1{
	    public int x = 5;
	    protected int y =45;
	    int z = 6;
	    private int a = 78;
	  
	}
	
	class C3 extends C1{
		
	}
	public class AccessSpecifiers {
	    public static void main(String[] args) {
	        C1 c = new C1();
	        C3 cs =new C3();
	        System.out.println(c.x);
	        System.out.println(c.y);
	        System.out.println(c.z);
	        // System.out.println(c.a);  -->private variables not accessible outside the class
	        
	        System.out.println(cs.y); 
	        //protected variable accessible to subclass
	        
	    }

}
