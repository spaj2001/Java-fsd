package pp4;

class StudentInfo{
	int rollNo;
	String name;

void StudentInfo() {
	System.out.println(rollNo+" "+name);
}

public int StudentInfo(int r, String n) {
	 rollNo=r;
	 name= n;
	 System.out.println(rollNo+" "+name);
	 return 0;
}
}

public class Constructor{

public static void main(String[] args) {

	StudentInfo s1=new StudentInfo();
	StudentInfo s2=new StudentInfo();
	StudentInfo s3=new StudentInfo();
	StudentInfo s4=new StudentInfo();
	
	s1.StudentInfo();
	s3.StudentInfo();
	s3.StudentInfo( 4, "Suresh");
	s4.StudentInfo(18, "Raman");
	}

}
